
############################################################
# Mappings from:
# Run Configuration names -> Assignment specific info files
############################################################
set(DonQuixote            "CS370_Assign01_Fa26/assignment_info.cmake")
set(RollinTrain           "CS370_Assign02_Fa26/assignment_info.cmake")
set(LimeLight             "CS370_Assign03_Fa26/assignment_info.cmake")
set(WalkingMan            "CS370_Assign04_Fa26/assignment_info.cmake")
set(exam01_fa26           "CS370_Exam01_Fa26/assignment_info.cmake")
set(exam02_fa26           "CS370_Exam02_Fa26/assignment_info.cmake")
set(exam03_fa26           "CS370_Exam03_Fa26/assignment_info.cmake")
