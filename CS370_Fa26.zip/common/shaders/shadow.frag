#version 400 core


void main()
{
    // Only want depth information from framebuffer
}
