
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 370")
set(TERM "Fall")
set(PROJECT_NUMBER "assign02")
set(PROJECT_NAME "RollinTrain")
set(SRC_FOLDER "CS370_Assign02_Fa26")
