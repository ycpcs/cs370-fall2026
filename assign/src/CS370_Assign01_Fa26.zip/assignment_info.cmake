
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 370")
set(TERM "Fall")
set(PROJECT_NUMBER "assign01")
set(PROJECT_NAME "DonQuixote")
set(SRC_FOLDER "CS370_Assign01_Fa26")
