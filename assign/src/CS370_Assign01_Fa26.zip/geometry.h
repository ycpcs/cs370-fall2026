// Model vertex arrays and buffer objects
enum VAO_IDs {Square, Triangle, Sun, NumVAOs};
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLint numVertices[NumVAOs];

// Color buffers
enum Color_Buffer_IDs {SkyBlue, GrassGreen, HouseBrown, RoofRed, FanBlue, SunYellow, NumColorBuffers};
GLuint ColorBuffers[NumColorBuffers];

// Number of sun vertices
#define NUM_SUN 361

void build_square(GLuint obj);
void build_triangle(GLuint obj);
void build_solid_color_buffer(GLuint num_vertices, vec4 color, GLuint buffer);
void build_gradient_color_buffer(vector<ivec3> indices, vector<vec4> colors, GLuint c_buff);
void build_sun(GLuint obj, GLuint c_buff);

void build_geometry( )
{
    // Generate vertex arrays for objects
    glGenVertexArrays(NumVAOs, VAOs);

    // Generate color buffers
    glGenBuffers(NumColorBuffers, ColorBuffers);
    
    // Build square
    build_square(Square);
    
    // TODO: Build square solid color buffers

    
    // Build triangle
    build_triangle(Triangle);
    
    // TODO: Build triangle solid color buffers


	// Build sun
	build_sun(Sun, SunYellow);
}

void build_square(GLuint obj) {
    vector<vec2> vertices;
    vector<ivec3> indices;

    // Bind square
    glBindVertexArray(VAOs[obj]);

    // TODO: Define square vertices
    vertices = {
            { 1.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f,-1.0f},
            { 1.0f,-1.0f},
    };

    // TODO: Define square face indices (ensure proper orientation)
    indices = {};
    int numFaces = indices.size();
    // Set numVertices as total number of INDICES (3*number of faces)
    numVertices[obj] = 3*numFaces;

    // Create gradient colors
    vector<vec4> blue_grad, green_grad;
    // TODO: Define blue sky color
    blue_grad = {};
    // TODO: Build sky gradient color buffer
    

    // TODO: Define green grass color
    green_grad = {};
    // TODO: Build grass gradient color buffer
    

    // TODO: Create object vertices from faces


    // Generate object buffers for obj
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);

    // TODO: Bind and load position object buffer for obj


}

void build_triangle(GLuint obj) {
    vector<vec2> vertices;
    vector<ivec3> indices;

    // Bind vertex array for obj
    glBindVertexArray(VAOs[obj]);

    // Define triangle vertices
    vertices = {
            { 1.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f,-1.0f},
    };

    // TODO: Define triangle indices (ensure proper orientation)
    indices = {};
    int numFaces = indices.size();
    // Set numVertices as total number of INDICES (3*number of faces)
    numVertices[obj] = 3*numFaces;

    // TODO: Define blue fan color
    vector<vec4> blue_grad = {};
    // TODO: Build fan gradient color buffer


    // TODO: Create object vertices from faces


    // Generate object buffers for obj
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);

    // TODO: Bind and load position object buffer for obj


}

void build_sun(GLuint obj, GLuint c_buff) {
    vector<vec4> vertices;
    vector<vec4> yellow_grad;

    // Bind vertex array for obj
    glBindVertexArray(VAOs[obj]);

    // TODO: Define sun vertices and colors

	// Set numVertices
    numVertices[obj] = vertices.size();

    // Generate object buffers for obj
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);

    // TODO: Bind and load position object buffer for obj


    // TODO: Bind and load color buffer


}

void build_solid_color_buffer(GLuint num_vertices, vec4 color, GLuint buffer) {
    // Create object colors
    vector<vec4> obj_colors;
    for (int i = 0; i < num_vertices; i++) {
        obj_colors.push_back(color);
    }

    // Bind and load color buffers
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[buffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*colCoords*num_vertices, obj_colors.data(), GL_STATIC_DRAW);
}

void build_gradient_color_buffer(vector<ivec3> indices, vector<vec4> colors, GLuint c_buff) {
    int num_faces = indices.size();
    // Create object colors
    vector<vec4> obj_colors;
    for (int i = 0; i < num_faces; i++) {
        for (int j = 0; j < 3; j++) {
            obj_colors.push_back(colors[indices[i][j]]);
        }
    }

    // Bind and load color buffers
    glBindBuffer(GL_ARRAY_BUFFER, ColorBuffers[c_buff]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*colCoords*3*num_faces, obj_colors.data(), GL_STATIC_DRAW);
}

