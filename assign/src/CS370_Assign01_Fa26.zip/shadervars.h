// Shader variables
// Color shader program references
extern GLuint color_program;
extern GLuint color_vPos;
extern GLuint color_vCol;
extern GLuint color_proj_mat_loc;
extern GLuint color_cam_mat_loc;
extern GLuint color_model_mat_loc;
