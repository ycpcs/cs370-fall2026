
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 370")
set(TERM "Fall")
set(PROJECT_NUMBER "assign03")
set(PROJECT_NAME "LimeLight")
set(SRC_FOLDER "CS370_Assign03_Fa26")
