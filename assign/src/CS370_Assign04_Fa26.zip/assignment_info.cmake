
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 370")
set(TERM "Fall")
set(PROJECT_NUMBER "assign04")
set(PROJECT_NAME "WalkingMan")
set(SRC_FOLDER "CS370_Assign04_Fa26")
