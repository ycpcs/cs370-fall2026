
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "HouseProject")
set(SRC_FOLDER "CS370_Project_Fa26")
