
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "helloOpenGLSol")
set(SRC_FOLDER "CS370_Lab00_Solution")
