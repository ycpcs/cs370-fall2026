
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "basicGeometrySol")
set(SRC_FOLDER "CS370_Lab01_Solution")
