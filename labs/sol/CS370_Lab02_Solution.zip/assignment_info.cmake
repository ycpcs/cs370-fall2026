
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shadedHexagonSol")
set(SRC_FOLDER "CS370_Lab02_Solution")
