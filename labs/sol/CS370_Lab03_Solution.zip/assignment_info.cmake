
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "transformHexagonSol")
set(SRC_FOLDER "CS370_Lab03_Solution")
