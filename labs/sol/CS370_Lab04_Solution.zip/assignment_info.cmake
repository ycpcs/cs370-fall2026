
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "spinningHexagonSol")
set(SRC_FOLDER "CS370_Lab04_Solution")
