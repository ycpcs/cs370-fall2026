
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "orthoCubeSol")
set(SRC_FOLDER "CS370_Lab05_Solution")
