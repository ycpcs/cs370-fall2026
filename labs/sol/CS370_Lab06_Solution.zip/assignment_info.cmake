
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "frustumSceneSol")
set(SRC_FOLDER "CS370_Lab06_Solution")
