
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shaderSceneSol")
set(SRC_FOLDER "CS370_Lab07_Solution")
