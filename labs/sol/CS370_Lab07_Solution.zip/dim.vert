#version 400 core
uniform mat4 model_matrix;
uniform mat4 proj_matrix;
uniform mat4 camera_matrix;
uniform float dim_factor;

layout(location = 0) in vec4 vPosition;
layout(location = 1) in vec4 vColor;

out vec4 oColor;

void main()
{
    gl_Position = proj_matrix*camera_matrix*model_matrix*vPosition;
    oColor = dim_factor*vColor;
    //oColor = vec4(1.0,1.0,1.0,1.0);
}
