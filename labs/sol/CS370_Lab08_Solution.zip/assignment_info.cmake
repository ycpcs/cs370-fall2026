
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "fogSceneSol")
set(SRC_FOLDER "CS370_Lab08_Solution")
