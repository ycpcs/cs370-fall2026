
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "gouraudMeshSol")
set(SRC_FOLDER "CS370_Lab09_Solution")
