
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "phongMeshSol")
set(SRC_FOLDER "CS370_Lab10_Solution")
