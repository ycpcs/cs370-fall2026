
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "blendedMeshSol")
set(SRC_FOLDER "CS370_Lab11_Solution")
