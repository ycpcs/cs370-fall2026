
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "blenderMonkeySol")
set(SRC_FOLDER "CS370_Lab12_Solution")
