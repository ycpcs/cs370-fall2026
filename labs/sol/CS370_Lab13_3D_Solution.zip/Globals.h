using namespace vmath;
using namespace std;

// Buffer enums
enum ObjBuffer_IDs {PosBuffer, NormBuffer, TexBuffer, NumObjBuffers};

// Number of component coordinates
GLint posCoords = 4;
GLint normCoords = 3;
GLint texCoords = 2;
GLint colCoords = 4;

// Global state
mat4 proj_matrix;
mat4 camera_matrix;
mat4 model_matrix;

// Initial Camera
vec3 eye = {0.0f, 0.0f, 4.0f};
vec3 center = {0.0f, 0.0f, 0.0f};
vec3 up = {0.0f, 1.0f, 0.0f};

// Global sphere variables
GLfloat earth_angle = 0.0f;
GLfloat moon_angle = 0.0f;
GLdouble rpm = 10.0;
vec3 axis = {0.0f, 1.0f, 0.0f};
GLdouble elTime = 0.0;
GLboolean animate = true;

// Stereo 3D variables
GLfloat sep = 0.0f;    // eye separation
GLboolean stereo = false;   // stereo 3D toggle

// Global screen dimensions
GLint ww = 640;
GLint hh = 480;
