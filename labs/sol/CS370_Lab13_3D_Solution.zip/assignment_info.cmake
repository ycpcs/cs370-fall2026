
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "earthMoonSol_3D")
set(SRC_FOLDER "CS370_Lab13_3D_Solution")
