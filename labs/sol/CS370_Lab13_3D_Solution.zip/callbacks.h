void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // Escape exits program
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // Space toggles animation
    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        animate = !animate;
    }
    
    // Adjust stereo separation with arrow keys
    if (stereo) {
        if (key == GLFW_KEY_LEFT && action == GLFW_PRESS) {
            sep += 0.02;
        }
        else if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS) {
            sep -= 0.02;
        }
        printf("x: %f  y: %f  z: %f\n",eye[0],eye[1],eye[2]);
    }

    // M toggles stereo 3D mode
    if (key == GLFW_KEY_M && action == GLFW_PRESS) {
        stereo = !stereo;
        // Adjust window size accordingly
        GLint w;
        GLint h;
        glfwGetWindowSize(window, &w, &h);
        if (stereo) {
            glfwSetWindowSize(window, 2*w, h);
        } else {
            glfwSetWindowSize(window, w/2, h);
        }
    }
}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){

}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);

    ww = width;
    hh = height;
}
