#define STB_IMAGE_IMPLEMENTATION
#include "../common/stb_image.h"	// Sean Barrett's image loader - http://nothings.org/
#include <iostream>
#include <stdio.h>
#include <vector>
#include "../common/GLFWutils.h"
#include "../common/textureutils.h"
#include "../common/objloader.h"
#include "../common/vmath.h"
#include "Globals.h"
#include "geometry.h"
#include "textures.h"
#include "drawObjects.h"
#include "shaders.h"
#include "callbacks.h"

void display( );
void render_scene( );

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Earth Moon", ww, hh);
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // Store initial window size
    glfwGetFramebufferSize(window, &ww, &hh);

    // Register callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window,key_callback);
    glfwSetMouseButtonCallback(window, mouse_callback);

	// Create geometry buffers
    build_geometry();
    // Create textures
    build_textures();
	// Create shaders
	build_shaders();

    // Enable depth test
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

	// Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Update angle based on time for fixed rpm
        GLdouble curTime = glfwGetTime();
        if (animate) {
            earth_angle += (curTime - elTime) * (rpm / 60.0) * 360.0;
            moon_angle += (curTime - elTime) * (rpm / 60.0) * 360.0;
        }
        elTime = curTime;
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
    // Stereo 3D local resolution copies (for full-frame SBS)
    GLint sw = ww;
    GLint sh = hh;

    proj_matrix = mat4().identity();
    camera_matrix = mat4().identity();

	// Clear window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // For stereo 3D each eye viewport is half total width
    if (stereo) {
        sw = ww/2;
    }

    // Set projection matrix
    // Set orthographic viewing volume anisotropic
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (sw <= sh)
    {
        yratio = (GLfloat)sh / (GLfloat)sw;
    }
        // If wider than tall adjust x
    else if (sh <= sw)
    {
        xratio = (GLfloat)sw / (GLfloat)sh;
    }
    
    if (!stereo) {
    	// Standard output
        // Set viewport
        glViewport(0, 0, sw, sh);
    	// Render background
		draw_background(Background, Space);
    	// Set projection matrix
    	proj_matrix = frustum(-1.0f*xratio, 1.0f*xratio, -1.0f*yratio, 1.0f*yratio, 1.0f, 100.0f);

    	// Set camera matrix
    	camera_matrix = lookat(eye, center, up);

    	// Render objects
		render_scene();

		glFlush();
	} else {
        // full-frame sbs stereo 3D
        // Set left viewport
        glViewport(0, 0, sw, sh);
        // Render background
        draw_background(Background, Space);
        vec3 eshift = normalize(vec3((center[2]-eye[2]),0,-(center[0]-eye[0])));
        // Render left scene
        proj_matrix = frustum(-1.0f*xratio, 1.0f*xratio, -1.0f*yratio, 1.0f*yratio, 1.0f, 100.0f);
        vec3 leye = eye - sep*eshift;
        vec3 lcen = center - sep*eshift;
        // Set camera matrix
        camera_matrix = lookat(leye, lcen, up);
        render_scene( );

        // Set right viewport
        glViewport(sw+1, 0, sw, sh);
        // Render background
        draw_background(Background, Space);
        // Render right scene
        proj_matrix = frustum(-1.0f*xratio, 1.0f*xratio, -1.0f*yratio, 1.0f*yratio, 1.0f, 100.0f);
        vec3 reye = eye + sep*eshift;
        vec3 rcen = center + sep*eshift;
        // Set camera matrix
        camera_matrix = lookat(reye, rcen, up);
        render_scene( );
	}
}

void render_scene( ) {
    model_matrix = mat4().identity();
    mat4 scale_matrix = mat4().identity();
    mat4 rot_matrix = mat4().identity();
    mat4 trans_matrix = mat4().identity();
	mat4 rot2_matrix = mat4().identity();


    // Set earth transformation matrix
    trans_matrix = translation(0.0f, 0.0f, 0.0f);
    rot_matrix = rotation(earth_angle, normalize(axis));
    scale_matrix = scale(1.0f, 1.0f, 1.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    // TODO: Draw earth
    draw_tex_object(Sphere, Earth);

    // Set moon transformation matrix
    rot_matrix = rotation(moon_angle, normalize(axis));
    scale_matrix = scale(0.25f, 0.25f, 0.25f);
    trans_matrix = translation(2.0f, 0.0f, 0.0f);
    model_matrix = rot_matrix*trans_matrix*rot_matrix*scale_matrix;
    // TODO: Draw moon
    draw_tex_object(Sphere, Moon);
}
