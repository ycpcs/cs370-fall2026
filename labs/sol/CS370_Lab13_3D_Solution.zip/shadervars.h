// Shader variables
// Texture shader program references
extern GLuint texture_program;
extern GLuint texture_vPos;
extern GLuint texture_vTex;
extern GLuint texture_proj_mat_loc;
extern GLuint texture_camera_mat_loc;
extern GLuint texture_model_mat_loc;
