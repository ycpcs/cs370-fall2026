
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "earthMoonSol")
set(SRC_FOLDER "CS370_Lab13_Solution")
