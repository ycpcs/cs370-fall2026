
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "robotGraphSol")
set(SRC_FOLDER "CS370_Lab14_Solution")
