
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "multiShadowMeshSol")
set(SRC_FOLDER "CS370_Lab15_MultiLight_Solution")
