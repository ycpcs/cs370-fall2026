// Shader variables
// Light shader program with shadows reference
extern GLuint phong_multi_shadow_program;
extern GLuint phong_multi_shadow_vPos;
extern GLuint phong_multi_shadow_vNorm;
extern GLuint phong_multi_shadow_proj_mat_loc;
extern GLuint phong_multi_shadow_camera_mat_loc;
extern GLuint phong_multi_shadow_norm_mat_loc;
extern GLuint phong_multi_shadow_model_mat_loc;
extern GLuint phong_multi_shadow_shad1_proj_mat_loc;
extern GLuint phong_multi_shadow_shad1_cam_mat_loc;
extern GLuint phong_multi_shadow_shad2_proj_mat_loc;
extern GLuint phong_multi_shadow_shad2_cam_mat_loc;
extern GLuint phong_multi_shadow_lights_block_idx;
extern GLuint phong_multi_shadow_materials_block_idx;
extern GLuint phong_multi_shadow_material_loc;
extern GLuint phong_multi_shadow_num_lights_loc;
extern GLuint phong_multi_shadow_light_on_loc;
extern GLuint phong_multi_shadow_eye_loc;
extern GLuint phong_multi_shadow_shadow1_loc;
extern GLuint phong_multi_shadow_shadow2_loc;

// Shadow map shader program reference
extern GLuint shadow_program;
extern GLuint shadow_vPos;
extern GLuint shadow_proj_mat_loc;
extern GLuint shadow_camera_mat_loc;
extern GLuint shadow_model_mat_loc;

// Debug shadow program reference
extern GLuint debug_program;
