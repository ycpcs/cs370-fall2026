
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shadowMeshSol")
set(SRC_FOLDER "CS370_Lab15_Solution")
