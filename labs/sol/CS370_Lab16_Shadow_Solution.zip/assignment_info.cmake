
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "mirrorMeshShadowSol")
set(SRC_FOLDER "CS370_Lab16_Shadow_Solution")
