// Shader variables
// Light shader program references
extern GLuint lighting_program;
extern GLuint lighting_vPos;
extern GLuint lighting_vNorm;
extern GLuint lighting_camera_mat_loc;
extern GLuint lighting_model_mat_loc;
extern GLuint lighting_proj_mat_loc;
extern GLuint lighting_norm_mat_loc;
extern GLuint lighting_lights_block_idx;
extern GLuint lighting_materials_block_idx;
extern GLuint lighting_material_loc;
extern GLuint lighting_num_lights_loc;
extern GLuint lighting_light_on_loc;
extern GLuint lighting_eye_loc;

// Texture shader program references
extern GLuint texture_program;
extern GLuint texture_vPos;
extern GLuint texture_vTex;
extern GLuint texture_proj_mat_loc;
extern GLuint texture_camera_mat_loc;
extern GLuint texture_model_mat_loc;

// Light shader program with shadows reference
extern GLuint phong_shadow_program;
extern GLuint phong_shadow_vPos;
extern GLuint phong_shadow_vNorm;
extern GLuint phong_shadow_proj_mat_loc;
extern GLuint phong_shadow_camera_mat_loc;
extern GLuint phong_shadow_norm_mat_loc;
extern GLuint phong_shadow_model_mat_loc;
extern GLuint phong_shadow_shad_proj_mat_loc;
extern GLuint phong_shadow_shad_cam_mat_loc;
extern GLuint phong_shadow_lights_block_idx;
extern GLuint phong_shadow_materials_block_idx;
extern GLuint phong_shadow_material_loc;
extern GLuint phong_shadow_num_lights_loc;
extern GLuint phong_shadow_light_on_loc;
extern GLuint phong_shadow_eye_loc;

// Shadow map shader program reference
extern GLuint shadow_program;
extern GLuint shadow_vPos;
extern GLuint shadow_proj_mat_loc;
extern GLuint shadow_camera_mat_loc;
extern GLuint shadow_model_mat_loc;

// Debug shadow program reference
extern GLuint debug_program;
