
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "mirrorMeshSol")
set(SRC_FOLDER "CS370_Lab16_Solution")
