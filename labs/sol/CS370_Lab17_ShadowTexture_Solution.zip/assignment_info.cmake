
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shadowTextureMeshSol")
set(SRC_FOLDER "CS370_Lab17_ShadowTexture_Solution")
