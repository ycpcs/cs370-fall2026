
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "multiTexMeshSol")
set(SRC_FOLDER "CS370_Lab17_Solution")
