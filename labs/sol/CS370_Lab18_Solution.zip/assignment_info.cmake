
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "bumpMeshSol")
set(SRC_FOLDER "CS370_Lab18_Solution")
