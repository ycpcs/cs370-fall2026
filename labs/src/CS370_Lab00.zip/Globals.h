// Global screen dimensions
GLint ww = 640;
GLint hh = 480;
