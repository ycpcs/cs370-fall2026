
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "helloOpenGL")
set(SRC_FOLDER "CS370_Lab00")
