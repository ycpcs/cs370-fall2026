using namespace vmath;
using namespace std;

// Buffer enums
enum ObjBuffer_IDs {PosBuffer, NumObjBuffers};

// Number of component coordinates
GLint posCoords = 2;

// Global screen dimensions
GLint ww = 640;
GLint hh = 480;
