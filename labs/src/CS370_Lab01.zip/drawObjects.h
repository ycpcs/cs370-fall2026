#include "shadervars.h"

void draw_basic_object(GLuint obj) {
    // TODO: Select shader program


    // TODO: Bind vertex array


    // TODO: Bind position object buffer and set attributes


    // TODO: Draw geometry


}
