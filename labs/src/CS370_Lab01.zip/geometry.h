// Model vertex arrays and buffer objects
enum VAO_IDs {Square, NumVAOs};
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLint numVertices[NumVAOs];

void build_square(GLuint obj);

void build_geometry( )
{
    // TODO: Generate vertex arrays for objects
   
    
    // TODO: Build square manually
    
    
}

void build_square(GLuint obj) {
    vector<vec2> vertices;

    // TODO: Bind vertex array for obj


    // TODO: Define vertices (ensure proper orientation)
    vertices = {};

    // TODO: Store number of vertices
    

    // TODO: Generate object buffers for obj


    // TODO: Bind and load position object buffer for obj
    
    
}
