// Shader variables
// Basic shader program references
extern GLuint basic_program;
extern GLuint basic_vPos;
