
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shadedHexagon")
set(SRC_FOLDER "CS370_Lab02")
