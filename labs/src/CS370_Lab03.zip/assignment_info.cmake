
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "transformHexagon")
set(SRC_FOLDER "CS370_Lab03")
