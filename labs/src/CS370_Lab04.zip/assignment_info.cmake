
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "spinningHexagon")
set(SRC_FOLDER "CS370_Lab04")
