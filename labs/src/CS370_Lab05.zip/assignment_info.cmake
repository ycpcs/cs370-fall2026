
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "orthoCube")
set(SRC_FOLDER "CS370_Lab05")
