
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "frustumScene")
set(SRC_FOLDER "CS370_Lab06")
