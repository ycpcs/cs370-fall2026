
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shaderScene")
set(SRC_FOLDER "CS370_Lab07")
