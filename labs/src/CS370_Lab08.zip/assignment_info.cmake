
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "fogScene")
set(SRC_FOLDER "CS370_Lab08")
