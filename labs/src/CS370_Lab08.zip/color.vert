#version 400 core
// TODO: Add uniform matrices (mat4)


// TODO: Add vertex attribute variables


// TODO: Add output variable (vec4)


void main()
{
    // TODO: Compute gl_Position transformed position
    
    
    // TODO: Set oColor output


}
