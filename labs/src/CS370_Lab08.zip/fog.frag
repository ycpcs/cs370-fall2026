#version 400 core
// TODO: Define input shader variable (vec4)


// TODO: Define output shader variable (vec4)


// TODO: Define uniform shader variables for fog


void main()
{
    // TODO: Compute fog factor


    // TODO: Compute output color
   
   
}
