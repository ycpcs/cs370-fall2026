// Shader variables
// Fog shader program references
extern GLuint fog_program;
extern GLuint fog_vPos;
extern GLuint fog_vCol;
extern GLuint fog_proj_mat_loc;
extern GLuint fog_cam_mat_loc;
extern GLuint fog_model_mat_loc;
extern GLuint fog_fog_col_loc;
extern GLuint fog_fog_start_loc;
extern GLuint fog_fog_end_loc;
