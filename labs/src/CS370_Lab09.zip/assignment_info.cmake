
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "gouraudMesh")
set(SRC_FOLDER "CS370_Lab09")
