
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "phongMesh")
set(SRC_FOLDER "CS370_Lab10")
