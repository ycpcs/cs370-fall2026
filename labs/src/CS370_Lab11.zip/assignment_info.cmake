
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "blendedMesh")
set(SRC_FOLDER "CS370_Lab11")
