
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "blenderMonkey")
set(SRC_FOLDER "CS370_Lab12")
