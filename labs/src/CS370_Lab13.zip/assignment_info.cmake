
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "earthMoon")
set(SRC_FOLDER "CS370_Lab13")
