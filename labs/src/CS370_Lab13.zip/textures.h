// Textures
enum Textures {Earth, Moon, Space, NumTextures};

// Texture files
const char * earthFile = "../textures/earth.png";
const char * moonFile = "../textures/moon.bmp";
const char * spaceFile = "../textures/space.jpg";
GLuint TextureIDs[NumTextures];

void load_texture(const char * filename, GLuint texID, GLint magFilter, GLint minFilter, GLint sWrap, GLint tWrap, bool mipMap, bool invert);

void build_textures() {

    // Create textures and activate unit 0
    glGenTextures( NumTextures,  TextureIDs);
    glActiveTexture( GL_TEXTURE0 );

    // TODO: Load texture images
    
    
}

void load_texture(const char * filename, GLuint texID, GLint magFilter, GLint minFilter, GLint sWrap, GLint tWrap, bool mipMap, bool invert) {
    int w, h, n;
    int force_channels = 4;
    unsigned char *image_data;

    // Activate unit 0
    glActiveTexture( GL_TEXTURE0 );

    image_data = stbi_load(filename, &w, &h, &n, force_channels);
    if (!image_data) {
        fprintf(stderr, "ERROR: could not load %s\n", filename);
        return;
    }
    printf("Successfully Loaded %s: %d x %d\n", filename, w, h);
    // NPOT check for power of 2 dimensions
    if ((w & (w - 1)) != 0 || (h & (h - 1)) != 0) {
        fprintf(stderr, "WARNING: texture %s is not power-of-2 dimensions\n", filename);
    }
    
    // Invert image (e.g. jpeg, png)
    if (invert) {
        int width_in_bytes = w * 4;
        unsigned char *top = NULL;
        unsigned char *bottom = NULL;
        unsigned char temp = 0;
        int half_height = h / 2;

        for ( int row = 0; row < half_height; row++ ) {
            top = image_data + row * width_in_bytes;
            bottom = image_data + ( h - row - 1 ) * width_in_bytes;
            for ( int col = 0; col < width_in_bytes; col++ ) {
                temp = *top;
                *top = *bottom;
                *bottom = temp;
                top++;
                bottom++;
            }
        }
	}

    // TODO: Bind current texture id
    
    
    // TODO: Load image data into texture


    if (mipMap) {
    	// TODO: Generate mipmaps for texture
        
        
    }
    // TODO: Set scaling modes


    // TODO: Set wrapping modes


    // Set maximum anisotropic filtering for system
    GLfloat max_aniso = 0.0f;
    glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &max_aniso);
    // set the maximum!
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, max_aniso);
}
