
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "robotGraph")
set(SRC_FOLDER "CS370_Lab14")
