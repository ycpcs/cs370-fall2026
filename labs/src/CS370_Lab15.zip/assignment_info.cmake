
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "shadowMesh")
set(SRC_FOLDER "CS370_Lab15")
