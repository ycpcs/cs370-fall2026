
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "mirrorMesh")
set(SRC_FOLDER "CS370_Lab16")
