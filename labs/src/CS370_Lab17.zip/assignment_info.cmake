
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "multiTexMesh")
set(SRC_FOLDER "CS370_Lab17")
