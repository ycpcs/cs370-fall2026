
############################################################
# Assignment specific info
############################################################
set(PROJECT_NAME "bumpMesh")
set(SRC_FOLDER "CS370_Lab18")
